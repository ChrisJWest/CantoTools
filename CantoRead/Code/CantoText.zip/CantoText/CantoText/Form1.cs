﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CantoText
{
    public partial class Form1 : Form
    {

        private static Dictionary<string, List<string>> myDictionary;
        private static Dictionary<string, int> knownWordBank;
        private static Dictionary<string, int> freqList;

        private static List<string> savedWords;
        private static List<string> pages;
        private static List<string> names;
        private static List<string> paths;
        private static List<int> bookmarks;

        private static int pageNum;
        private static int maxPages;
        private static StringBuilder sb;
        private static Color knownWordColor;
        private static Color learningWordColor;
        private static Color unknownWordColor;

        private static string bookmarkPath;
        private static string wordslistPath;
        private static string backupwordslistPath;
        private static string dictionaryPath;
        private static string freqlistPath;
        private static string saveDailyWordsPath;

        public Form1()
        {
            InitializeComponent();

            // Intialize Form variables
            sb = new StringBuilder();
            savedWords = new List<string>();
            pages = new List<string>();
            names = new List<string>();
            paths = new List<string>();
            bookmarks = new List<int>();
            knownWordBank = new Dictionary<string, int>();
            freqList = new Dictionary<string, int>();
            knownWordColor= Color.White;
            knownWordColor = Color.FromArgb(200, 200, 200);
            learningWordColor = Color.FromArgb(27, 46, 79);
            unknownWordColor = Color.FromArgb(74, 21, 43);

            //bookmarkPath = @"C:\Users\porti\source\repos\CantoText\CantoText\BooksPathsBookmarks.txt";
            //wordslistPath = @"C:\Users\porti\source\repos\CantoText\CantoText\HK_WordList.csv";
            //backupwordslistPath = @"C:\Users\porti\source\repos\CantoText\CantoText\HK_WordList_Backup.csv";

            //dictionaryPath = "C://Users//porti//source//repos//CantoText//CantoText//CantoDict.json";
            //freqlistPath = @"C:\Users\porti\source\repos\CantoText\CantoText\freq.csv";
            //saveDailyWordsPath = @"C:\Users\porti\source\repos\CantoText\CantoText\TodayWordlist.txt";



            //bookmarkPath = @"C:\Users\porti\Documents\LingoFiles\Canto\BooksPathsBookmarks.txt";
            //wordslistPath = @"C:\Users\porti\Documents\LingoFiles\Canto\HK_WordList.csv";
            //backupwordslistPath = @"C:\Users\porti\Documents\LingoFiles\Canto\HK_WordList_Backup.csv";

            //dictionaryPath = @"C:\Users\porti\Documents\LingoFiles\Canto\CantoDict.json";
            //freqlistPath = @"C:\Users\porti\Documents\LingoFiles\Canto\FreqList.csv";
            //saveDailyWordsPath = @"C:\Users\porti\Documents\LingoFiles\Canto\TodayWordlist.txt";

            string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;

            bookmarkPath = projectDirectory + "BooksPathsBookmarks.txt";
            wordslistPath = projectDirectory + "HK_WordList.csv";
            backupwordslistPath = projectDirectory + "HK_WordList_Backup.csv";

            dictionaryPath = projectDirectory + "CantoDict.json";
            freqlistPath = projectDirectory + "FreqList.csv";
            saveDailyWordsPath = projectDirectory + "TodayWordlist.txt";

            // Load in your known words
            using (var reader = new StreamReader(wordslistPath))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');

                    if (!knownWordBank.ContainsKey(values[0]))
                    {
                        knownWordBank.Add(values[0], Int32.Parse(values[1]));
                    }
                }
            }

            // Load in books from bookmarks file
            pageNum = 0;
            string readTextBooks = File.ReadAllText(bookmarkPath);
            using (var reader = new StringReader(readTextBooks))
            {
                for (string line = reader.ReadLine(); line != null; line = reader.ReadLine())
                {
                    string[] words = line.Split(' ');
                    comboBox1.Items.Add(words[0]);
                    names.Add(words[0]);
                    paths.Add(words[1]);
                    bookmarks.Add(Int32.Parse(words[2]));
                }
                // Also load in button event functions
                button1.Click += new EventHandler(Button1OnClick);
                button2.Click += new EventHandler(Button2OnClick);
                button3.Click += new EventHandler(Button3OnClick);
                button5.Click += new EventHandler(Button5OnClick);
                button6.Click += new EventHandler(Button6OnClick);
            }
            richTextBox1.AutoWordSelection = false;
            richTextBox1.HideSelection = false;
            this.WindowState = FormWindowState.Maximized;
            richTextBox1.AutoWordSelection = false;
            richTextBox1.SelectionChanged +=
                new EventHandler(RichTextBox1_SelectionChanged);
            richTextBox1.KeyPress +=
                new System.Windows.Forms.KeyPressEventHandler(this.richTextBox1_KeyPress);
            textBox1.KeyPress +=
                new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);

            // Load in Dictionary
            StreamReader r = new StreamReader(dictionaryPath);
            string jsonString = r.ReadToEnd();
            List<Class1> m = JsonConvert.DeserializeObject<List<Class1>>(jsonString);

            myDictionary = new Dictionary<string, List<string>>();
            foreach (var i in m)
            {
                if (!myDictionary.ContainsKey(i.term))
                    myDictionary.Add(i.term, new List<string>() {i.pronunciation, i.definition});
            }

            // Load in frequency list
            using (var reader = new StreamReader(freqlistPath))
            {
                int i = 1;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');

                    freqList.Add(values[0], i);
                    i++;
                }
            }
        }

        private void renderAtPage()
        {
            sb.Clear();
            textBox1.Text = pageNum.ToString();
            string textGrabbed = pages[pageNum];

            int maxCharWordLength = 6;
            var tokens = new List<string>();
            var starts = new List<int>();
            for (int i = 0; i < textGrabbed.Length - maxCharWordLength; i += 1)
            {
                string largestWord = textGrabbed.Substring(i, 1);
                for (int ii = 2; ii < maxCharWordLength; ii += 1)
                {
                    string h = textGrabbed.Substring(i, ii);
                    if (myDictionary.ContainsKey(h))
                        largestWord = h;
                }
                starts.Add(i);
                i = i + largestWord.Length - 1;
                tokens.Add(largestWord);
                sb.Append(largestWord + " ");
            }
            richTextBox1.Text = sb.ToString();
            richTextBox1.ForeColor = knownWordColor;
            //richTextBox1.Text = "test";
            for (int j = 0; j < tokens.Count; j++) // Bug somewhere here
            {
                if (knownWordBank.ContainsKey(tokens[j]))
                {
                    int memory = knownWordBank[tokens[j]];
                    int goodMem = 2;
                    if (memory.CompareTo(goodMem) == 0)
                    {
                    } else
                    {
                        Color myRgbColor = new Color();
                        myRgbColor = Color.FromArgb(3, 28, 252);
                        richTextBox1.SelectionStart = starts[j] + j;
                        richTextBox1.SelectionLength = tokens[j].Length;
                        richTextBox1.SelectionColor = learningWordColor;
                    }
                }
                else
                {
                    richTextBox1.SelectionStart = starts[j] + j;
                    richTextBox1.SelectionLength = tokens[j].Length;
                    richTextBox1.SelectionColor = unknownWordColor;
                }
            }
            richTextBox1.SelectionStart = 0;
            richTextBox1.SelectionLength = 0;
        }


        void Button3OnClick(object sender, EventArgs e)
        {
            pageNum = pageNum-1;
            renderAtPage();
        }

        void Button1OnClick(object sender, EventArgs e)
        {
            pageNum = pageNum + 1;
            renderAtPage();
        }

        void Button2OnClick(object sender, EventArgs e)
        {
            pages.Clear();
            int currentMyComboBoxIndex = comboBox1.FindStringExact(comboBox1.Text);
            string path = paths[currentMyComboBoxIndex];
            int bookmarkCurr = bookmarks[currentMyComboBoxIndex];
            pageNum = bookmarkCurr;
            string readText = File.ReadAllText(path);
            int splitAt = 250; // change 4 with the size of strings you want.
            for (int i = 0; i < readText.Length; i = i + splitAt)
            {
                if (readText.Length - i >= splitAt)
                    pages.Add(readText.Substring(i, splitAt));
                else
                    pages.Add(readText.Substring(i, ((readText.Length - i))));
            }
            //pageNum = 0;
            maxPages = pages.Count();
            label1.Text = "/ " + maxPages.ToString();
            renderAtPage();
        }

        void Button5OnClick(object sender, EventArgs e)
        {
            string fullString = "";
            for (int i = 0; i < savedWords.Count; i++)
            {
                fullString = fullString + savedWords[i] + "\n";
            }
            File.WriteAllText(saveDailyWordsPath, fullString);
        }

        void Button6OnClick(object sender, EventArgs e)
        {
            string selectedText = richTextBox1.SelectedText.Trim();

            try
            {
                string defin = myDictionary[selectedText][1];
                defin = Regex.Replace(defin, "(?<!\r)\n", "\r\n");
                defin = Regex.Replace(defin, "POS：.*· ", "");
                string saveWord = selectedText.Trim() + " - " + myDictionary[selectedText][0] + " - " + defin;
                savedWords.Add(saveWord);
            }
            catch
            {
                textBox2.Text = "Not found";
            }
        }

        private void RichTextBox1_SelectionChanged(Object sender, EventArgs e)
        {
            string selectedText = richTextBox1.SelectedText.Trim();

            try
            {
                string defin = myDictionary[selectedText][1];
                defin = Regex.Replace(defin, "(?<!\r)\n", "\r\n");
                defin = Regex.Replace(defin, "POS：.*· ", "");
                string freqCurr = "Frequency Data not Found";
                if (freqList.ContainsKey(selectedText.Trim()))
                {
                    freqCurr = freqList[selectedText.Trim()].ToString();
                    int freqValue = freqList[selectedText.Trim()];
                    if (freqValue <= 1500) {
                        freqCurr = "★★★★★";
                    } else if (freqValue <= 5000)
                    {
                        freqCurr = "★★★★";
                    } else if (freqValue <= 15000)
                    {
                        freqCurr = "★★★";
                    } else if (freqValue <= 30000)
                    {
                        freqCurr = "★★";
                    } else {
                        freqCurr = "★";
                    }
                }
                textBox2.Text = selectedText.Trim() + Environment.NewLine + freqCurr + Environment.NewLine + myDictionary[selectedText][0] + Environment.NewLine + defin;
                }
            catch
            {
                textBox2.Text = "Not found";
            }
        }

        private void richTextBox1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            string trimmed = richTextBox1.SelectedText.Trim();
            try
            {
                if (e.KeyChar.ToString() == "1")
                {
                    if (knownWordBank.ContainsKey(trimmed))
                    {
                        knownWordBank[trimmed] = 1;
                    }
                    else
                    {
                        knownWordBank.Add(trimmed, 1);
                    }
                    richTextBox1.SelectionColor = learningWordColor;
                    int maxCharWordLength = 6;
                    var tokens = new List<string>();
                    var starts = new List<int>();
                    string textGrabbed = pages[pageNum];
                    for (int i = 0; i < textGrabbed.Length - maxCharWordLength; i += 1)
                    {
                        string largestWord = textGrabbed.Substring(i, 1);
                        for (int ii = 2; ii < maxCharWordLength; ii += 1)
                        {
                            string h = textGrabbed.Substring(i, ii);
                            if (myDictionary.ContainsKey(h))
                                largestWord = h;
                        }
                        starts.Add(i);
                        i = i + largestWord.Length - 1;
                        tokens.Add(largestWord);
                    }
                    for (int i = 0; i < tokens.Count; i += 1)
                    {
                        if (tokens[i] == trimmed)
                        {
                            richTextBox1.SelectionStart = starts[i] + i;
                            richTextBox1.SelectionLength = tokens[i].Length;
                            richTextBox1.SelectionColor = learningWordColor;
                        }
                    }
                    e.Handled = true;
                    //e.SuppressKeyPress = true;
                    //richTextBox1.SelectionStart = 0;
                    //richTextBox1.SelectionLength = 1;
                }
                if (e.KeyChar.ToString() == "2")
                {
                    if (knownWordBank.ContainsKey(trimmed))
                    {
                        knownWordBank[trimmed] = 2;
                    }
                    else
                    {
                        knownWordBank.Add(trimmed, 2);
                    }
                    richTextBox1.SelectionColor = knownWordColor;
                    int maxCharWordLength = 6;
                    var tokens = new List<string>();
                    var starts = new List<int>();
                    string textGrabbed = pages[pageNum];
                    for (int i = 0; i < textGrabbed.Length - maxCharWordLength; i += 1)
                    {
                        string largestWord = textGrabbed.Substring(i, 1);
                        for (int ii = 2; ii < maxCharWordLength; ii += 1)
                        {
                            string h = textGrabbed.Substring(i, ii);
                            if (myDictionary.ContainsKey(h))
                                largestWord = h;
                        }
                        starts.Add(i);
                        i = i + largestWord.Length - 1;
                        tokens.Add(largestWord);
                    }
                    for (int i = 0; i < tokens.Count; i += 1)
                    {
                        if (tokens[i] == trimmed)
                        {
                            richTextBox1.SelectionStart = starts[i] + i;
                            richTextBox1.SelectionLength = tokens[i].Length;
                            richTextBox1.SelectionColor = knownWordColor;
                        }
                    }
                    richTextBox1.SelectionStart = 0;
                    richTextBox1.SelectionLength = 1;
                    e.Handled = true;
                    //e.SuppressKeyPress = true;
                }
            }
            catch (Exception ex)
            {

            }

            
        }

        private void textBox1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (Convert.ToInt32(e.KeyChar) == 13)
            {
                pageNum = Int32.Parse(textBox1.Text);
                renderAtPage();
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }


        public class Rootobject
        {
            public Class1[] Property1 { get; set; }
        }

        public class Class1
        {
            public int id { get; set; }
            public string term { get; set; }
            public string altterm { get; set; }
            public string pronunciation { get; set; }
            public string pos { get; set; }
            public string definition { get; set; }
            public string examples { get; set; }
            public string audio { get; set; }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int currentMyComboBoxIndex = comboBox1.FindStringExact(comboBox1.Text);
            bookmarks[currentMyComboBoxIndex] = pageNum;
            string fullBooksString = "";
            for (int i = 0; i < names.Count; i++)
            {
                fullBooksString = fullBooksString + names[i] + " " + paths[i] + " " + bookmarks[i] + "\n";
            }
            File.WriteAllText(bookmarkPath, fullBooksString);

            // Now saving wordlist
            string fullBooksString2 = "";
            foreach (var item in knownWordBank)
            {
                fullBooksString2 = fullBooksString2 + item.Key.Trim() + "," + item.Value.ToString().Trim() + "\n";
            }
            //if (File.Exists(backupwordslistPath))
            //{
            //    File.Delete(backupwordslistPath);
            //}
            //File.Move(wordslistPath, backupwordslistPath);
            //System.IO.File.Move(wordslistPath, backupwordslistPath);
            File.WriteAllText(wordslistPath, fullBooksString2);
        }


        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

public static class RichTextBoxExtensions
{
    public static void AppendText(this RichTextBox box, string text, Color color, bool addNewLine = false)
    {
        box.SuspendLayout();
        box.SelectionColor = color;
        box.AppendText(addNewLine
            ? $"{text}{Environment.NewLine}"
            : text);
        box.ScrollToCaret();
        box.ResumeLayout();
    }
    public static void AppendText2(this RichTextBox box, string text, Color color)
    {
        box.SelectionStart = box.TextLength;
        box.SelectionLength = 0;

        box.SelectionColor = color;
        box.AppendText(text);
        box.SelectionColor = box.ForeColor;
    }
}
